<?php
   defined( 'ABSPATH' ) || exit;
?>
<!-- Rush Filter Global Header Html Markup -->
<div class="rushfilter-header">
	<div class="rushfilter-heading">
		<h2 class="rushfilter-main-heading"><img src=" <?php echo plugin_dir_url( __FILE__ ) . '/images/admin-filter.png'; ?> " class="admin-filter-icon"> Rush Filter Dashboard</h2>
		<a href="javascript:void(0)" onclick="openModal()" class="get-information-btn" id="getinfo">GET INFORMATIONS</a>
			<div class="modal">
			  <div class="modal-overlay" class="closeinfo"></div>
			  <div class="modal-card">
				<div class="modal-body">
				  <div class="modal-header"><h3>Rush Filter Informations</h3></div>
				  <div class="modal-content"><h4>What is an Ajax filter?</h4>
Image result for why important ajax post filter
A powerful WooCommerce plugin for products filtering. Filter your products by attributes, custom taxonomies, price, tags and product categories. You can select different types of widget like checkboxes, radio buttons, dropdown menu, range slider, tag cloud for tags, checkboxes with color or image.</div>
				  <div class="modal-footer" >
					Footer
					<button class="closeinfo">Okay</button>
				  	</div>
				</div>
			</div>
		</div>
	</div>
</div>