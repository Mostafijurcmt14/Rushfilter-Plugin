<?php
   defined( 'ABSPATH' ) || exit;
?>
